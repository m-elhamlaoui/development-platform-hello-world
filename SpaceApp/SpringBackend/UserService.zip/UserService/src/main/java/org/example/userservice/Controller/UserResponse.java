package org.example.userservice.Controller;

record UserResponse(
        String email,
        String name
) {}
